using FoodyGo.Core.Enums;

namespace FoodyGo.Core.Entities;

public class Order : BaseEntity
{
    public Guid UserId { get; set; }
    public User? User { get; set; }

    public Guid RestaurantId { get; set; }
    public Restaurant? Restaurant { get; set; }

    public decimal TotalAmount { get; set; }
    public OrderStatus Status { get; set; } = OrderStatus.Pending;
    public OrderType Type { get; set; } = OrderType.Standard;

    public ICollection<OrderItem> Items { get; set; } = new List<OrderItem>();
    public Review? Review { get; set; }
}
